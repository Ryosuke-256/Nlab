# Setup
```
git clone 
npm install
npm run dev
```